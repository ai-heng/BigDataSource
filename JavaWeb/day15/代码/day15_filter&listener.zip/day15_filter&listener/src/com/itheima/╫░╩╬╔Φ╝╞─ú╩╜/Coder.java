package com.itheima.装饰设计模式;

/*
    程序员接口
 */
public interface Coder {
    void code();

    /*
       JDK1.8的新特性.
    public static void show() {
        System.out.println(1 + 2);
    }

    public default void show2() {
        System.out.println(1 + 2);
    }*/
}
