package com.itheima.test01_测试Idea;

public class Test01 {
    /*
        psvm: main函数
        sout: 输出语句
     */
    public static void main(String[] args) {
        System.out.println("这是Day03_JDBC");
    }
}
