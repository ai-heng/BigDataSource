package com.itheima.test01;

public class Test01 {
    public static void main(String[] args) {
        System.out.println("我是.java文件, 我有.class字节码文件, 看看我的字节码文件在哪!");
    }
}
