package com.itheima.service;

/**
 * 操作分类信息的: 业务层接口
 */
public interface CategoryService {
    String findAllCategory();
}
